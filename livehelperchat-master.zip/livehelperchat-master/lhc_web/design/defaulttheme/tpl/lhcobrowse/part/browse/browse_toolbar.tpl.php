<div id="chrome" >
    <div class="container-fluid">
        <div class="row co-browse-toolbar">
            <?php include(erLhcoreClassDesign::designtpl('lhcobrowse/part/browse/browse_toolbar_left.tpl.php')); ?>

            <?php include(erLhcoreClassDesign::designtpl('lhcobrowse/part/browse/browse_toolbar_right.tpl.php')); ?>
        </div>
    </div>
</div>