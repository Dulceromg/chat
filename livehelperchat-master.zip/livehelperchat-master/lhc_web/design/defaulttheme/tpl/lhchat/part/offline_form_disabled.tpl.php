<?php 
/**
 * There can be some error message if offline form is disabled
 * */
$errors = array('Offline form is disabled');
?>
<?php include(erLhcoreClassDesign::designtpl('lhkernel/validation_error.tpl.php'));?>