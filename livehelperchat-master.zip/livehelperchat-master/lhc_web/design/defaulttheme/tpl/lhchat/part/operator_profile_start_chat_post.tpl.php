<?php 
/**
 * Override to append some info near operator profile
 * */
?>