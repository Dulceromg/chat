<?php 
/**
 * You can have custom functionality above textarea of start chat
 * */
?>